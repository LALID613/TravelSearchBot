
from flask import Flask, render_template, request
from services.flights import get_flights
from services.hotels import get_hotels
from services.cars import get_cars
import os

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    results = {"flights": [], "hotels": [], "cars": []}
    tab = request.form.get("tab", "flights")

    if request.method == "POST":
        if tab == "flights":
            results["flights"] = get_flights(
                request.form["origin"], request.form["destination"], request.form["date"]
            )
        elif tab == "hotels":
            results["hotels"] = get_hotels(
                request.form["location"], request.form["checkin"], request.form["checkout"]
            )
        elif tab == "cars":
            results["cars"] = get_cars(
                request.form["location"], request.form["pickup"], request.form["dropoff"]
            )

    return render_template("index.html", tab=tab, results=results)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(debug=False, host="0.0.0.0", port=port)
