
def get_cars(location, pickup, dropoff):
    return [
        {"brand": "Hyundai", "type": "SUV", "price": 2000},
        {"brand": "Maruti", "type": "Hatchback", "price": 1500}
    ]
