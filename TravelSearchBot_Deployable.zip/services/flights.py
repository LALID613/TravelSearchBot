
import requests, os
from dotenv import load_dotenv
load_dotenv()

def get_flights(origin, destination, date):
    key = os.getenv("SKYSCANNER_KEY")
    url = f"https://skyscanner44.p.rapidapi.com/search?from={origin}&to={destination}&date={date}&adults=1"
    headers = {"X-RapidAPI-Key": key, "X-RapidAPI-Host": "skyscanner44.p.rapidapi.com"}
    try:
        r = requests.get(url, headers=headers)
        data = r.json().get("data", [])
        return [{
            "airline": f.get("airline", "Unknown"),
            "price": f.get("price", "N/A"),
            "departure_time": f.get("departure_time", "00:00"),
            "arrival_time": f.get("arrival_time", "00:00")
        } for f in data]
    except:
        return []
