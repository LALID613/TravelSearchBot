
def get_hotels(location, checkin, checkout):
    return [
        {"name": "Cozy Inn", "price": 2100, "city": location},
        {"name": "Urban Suites", "price": 3100, "city": location}
    ]
